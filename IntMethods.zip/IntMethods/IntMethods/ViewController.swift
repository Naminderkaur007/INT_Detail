

//Int 8 Range -128 to 127
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        useOfAdvance()
        
    }
    
    
    
        func checkABS(){
            
            //Returns the absolute value of the given number.
            //it convert the negative value to positive,it keeps the value positive
            
            let x = -100
            let y = abs(x)
            print("abs = \(y)")
        }
        
    
        func checkNegativeOrPositive(){
    //        Returns -1 if this value is negative and 1 if it’s positive; otherwise, 0.


            let x = 200 // -200
            print("Negative or Positive = \(x.signum())")
        }
        
    

        func useOfDescription(){
    //        A textual representation of this value.

    //it convert to string(description)
            let x = 100
            let y = x.description
            print("Description = \(y)")
        }
    
       
        func useOfDistance(){
    //        Returns the distance from this value to the given value, expressed as a stride.


            let a = 100
            let b = 250
            let distanceBetween = a.distance(to: b)
            print("Distance = \(distanceBetween)")
        }

        func useOfAdvance(){
    //        Returns a value that is offset the specified distance from this value.


            let a = 100
            let distanceBetween = 150
            let b = a.advanced(by: distanceBetween)
            print("second point = \(b)")
        }

    
    
  
       

}

