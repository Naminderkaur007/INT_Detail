

import UIKit

class DataViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    func initialization(){
       //different way of initialization
           
           
           //didn't define any size ,it will take default bit ,depends on the platform
           
               let x = 125
               print("x = \(x)")

            //Here we have two points at compile time Int8 handle the overflow the value and throw an error but if value come at runtime after the range it will crash
               let y = Int8(x)  //
               print("y = \(y)")

              //it will truncate
               let z = Int(1.9)
               print("z = \(z)")

           }
       
    
    func checkInitExactly(){
       //Creates a new instance from the given integer, if it can be represented exactly.
               
       //if value come under its range it will understand and read it give it optional value ,other wise it will give nil value
                   
       //it understand the underscore

               
               let a = 100
               let b = 1_00
               let c = 1000
               let d = 99.1
            
               let x = Int8(exactly: a)
               print("x exactly = \(x)")
            
               let y = Int8(exactly: b)
               print("y exactly = \(y)")
           
               let z = Int8(exactly: c)
               print("z exactly = \(z)")
       
               
               let z1 = Int8(exactly: d)
               //it will not truncate ,it will return nil here
               print("z1 exactly = \(z1)")
               
           }
       
  
    
    func checkInitClamping(){
         //        Creates a new instance with the representable value that’s closest to the given integer.
                
                 //it will take the nearest value

                 let x = Int8(clamping: -129)
                 print("x clamping = \(x)")
                 
             }
         
    
    func convertInitFromString(){
                 //Int8 its an function overloading same name function parameter different
                 //it will return optional value
                 //it will convert to integer if possibl othervise it will return nil value
                 
                 let x = Int8("123")
                 print("x= \(x)")
             }
         
        
             func getRandomValueWithNormalRange(){
                 
                 //we should used random in place of arcRandom(it is an c library method)
                 //random is a swift method it is an default method
                 for _ in 1...100{
                     print("RandomValue = \(Int.random(in: 1..<5))")
                 }
             }
         

             func getRandomValueWithCloseRange(){
                 for _ in 1...100{
                     print("RandomValue = \(Int.random(in: 1...5))")
                 }
             }
         
         
             func getNegativeInt(){
         //        Replaces this value with its additive inverse.
                 //it will return opposite value
                 var x = -21
                 x.negate()
                 print("Negative value = \(x)")
             }
    
    
     func getQuotientAndReminderInt(){
      //        Returns the quotient and remainder of this value divided by the given value.


              let x = 100
              let y = 3
              print(x/y) //quotent
              print(x%y) // reminder
      
              let (q, r) = x.quotientAndRemainder(dividingBy: y)
            
              print("quotient = \(q)")
              print("remainder = \(r)")
          }
     
     
    
     func checkMultiple(){
        //        Returns true if this value is a multiple of the given value, and false otherwise.

                let x = 26
    //            let reminder = x % 5
    //            if reminder == 0{
    //
    //                print("yes multiple")
    //            }else {
    //                print("No multiple")
    //            }
        
                print("\(x) is Multiple of 5 = \(x.isMultiple(of: 5))")
        
            }
          
       
       
       
       
            func getMagnitude(){
        //        The magnitude of this value.


                //Here we letting know that -200 is a value where - is a sign and 200 is a magnitude
                let x = -200
                
             //   print(x - 200)
                print("magnitude = \(x.magnitude)")
            }
       
           
         
     
     
     
         
         
  
}
